let salon={
    name: "Grooming Pets",
    address:{
        street: "123 Happy Pets Lane",
        zipcode: "22414",
        number: "262-K",
    },
    hours: {
        open: "5:00 a.m.",
        close: "11:00 p.m.",
    },
    pets: []
    }

    function init(){
        let scooby=new Pet("Scooby", 60, "Male","Dane", "Grooming","Shaggy", "561 - 953 - 1551");
        let rocky=new Pet( "Rocky",20, "Female", "Dane","Bath", "RockStar","581 - 953 - 1651");
        let cujo=new Pet("Cujo", 25,"Male","Pitbull","Overnight", "Josh","181 - 953 - 1251");
        let tiny=new Pet( "Tiny",31,"Female", "Poodle", "Grooming","Kaleb","561 - 953 - 1551");
        salon.pets.push(scooby, rocky, cujo, tiny);
    }
window.onload =init;

function displayPetNames(){
    alert(`You have ${salon.pets.length}pets.`);
    for (let i = 0; i < salon.pets.length; i++) {
        console.log(salon.pets[i].name);
        document.write(petName);
        window.onload = displayPetAges;
    }

//create the constructor
function Pet(name, age, gender, breed, service, ownerName, ownerPhone) {
    this.name = name;
    this.age = age;
    this.gender = gender;
    this.breed = breed;
    this.service = service;
    this.ownerName = ownerName;
    this.ownerPhone = ownerPhone;
}

//getting the inputs from the html
let petName= document.getElementById("txtName");
let displayPetAge= document.getElementById("txtAge");
let petGender= document.getElementById("txtGener");
let petBreed= document.getElementById("txtBreed");
let petService= document.getElementById("selService");
let petOwnerName= document.getElementById("txtBreed");
let petOwnerPhone= document.getElementById("txtOwnerPhone");

function register(){
    console.log ("Register");
    let thePet= new Pet (petName.value,petAge.value, petGender.value, petBreed.value, petService.value, petOwnerName.value, petOwnerPhone.value);
    console.log(thePet);
    salon.pets.push(thePet);
    console.log(salon.pets);
    showPetsCards();
    alert("Congrats! You have registered a new pet!");
}
function showPetsCards(){
    document.getElementById("petList").innerHTML=""
    for(let i=0,);i,salon.pets.length;i++){
        document.getElementById("petList").innerHTML +=createcard(salon.pets[i]);
    }
    function createCard(pet, index=0){
        return `
        <div class="pet-card">
            <h3>${pet.name}</h3>
            <p>Age: ${pet.age}</p>
            <p>Gender: ${pet.gender}</p>
            <p>Breed: ${pet.breed}</p>
            <p>Service: ${pet.service}</p>
            <p>Owner: ${pet.ownerName}</p>
            <p>OwnerPhone: ${pet.ownerPhone}</p>
            <button onclick="removePets(${index});">Remove</button>
        </div>
    },
